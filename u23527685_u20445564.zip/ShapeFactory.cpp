#include "ShapeFactory.h"

ShapeFactory::~ShapeFactory()
{
    
}