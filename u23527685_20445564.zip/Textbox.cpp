#include "Textbox.h"
#include "Shape.h"
#include <sstream>
#include <string>

using namespace std;

Textbox::Textbox(const Textbox &other):Shape(other){
    this->text=other.text;
}

Textbox::Textbox()
    : Shape(10,20,*(new string("black")),0,0){
        text="default";
    }

Textbox::Textbox(int l, int w, std::string &colour, int x, int y, std::string &txt)
    : Shape(l,w,colour,x,y), text(txt) {}

Textbox::~Textbox() {}

Shape* Textbox::clone()
{
    return new Textbox(*this);
}

std::string Textbox::toString()
{
   std::ostringstream out;
    out << "Textbox (length=" << getLength()
        <<", width="<<getWidth()
        << ", colour=" << getColour()
        << ", x=" << getPosition_x()
        << ", y=" << getPosition_y() 
        <<", text="<<text<< ")";
    return out.str();
}

void Textbox::changeText(string txt){
    text=txt;
}